import { Breadcrumb, SimpleCard } from 'app/components'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate, useParams } from 'react-router-dom'
import { Form, Button, Input, Select, Space } from 'antd'
import 'antd/dist/antd.min.css'
import { EditOutlined } from '@ant-design/icons'
import { editOrders } from './store/Orders.action'
import styled from 'styled-components'
import React, { useState } from 'react'

const Container = styled('div')(() => ({
    margin: '30px',
}))

const EditOrders = () => {
    const { id: OrdersId } = useParams()

    const Orders = useSelector((state) =>
        state.Orders.entities.find(
            (Orders) => Orders.id.toString() === OrdersId.toString()
        )
    )

    const dispatch = useDispatch()
    const navigate = useNavigate()

    const [title, setTitle] = useState(Orders.title)
    const [description, setDescription] = useState(Orders.description)

    const handleTitle = (e) => setTitle(e.target.value)
    const handleDescription = (e) => setDescription(e.target.value)

    const handleClick = (e) => {
        dispatch(
            editOrders({
                id: OrdersId,
                title,
                description,
            })
        ).then(() => navigate('/Orders'))
    }

    return (
        <Container>
            <Space
                direction="vertical"
                size="middle"
                style={{ display: 'flex' }}
            >
                <Breadcrumb
                    routeSegments={[
                        { name: 'EditOrders', path: '/Orders' },
                        { name: 'Form' },
                    ]}
                />
                <SimpleCard title="Edit Form">
                    <Form
                        initialValues={{
                            title: title,
                            description: description,
                        }}
                        autoComplete="off"
                        wrapperCol={{ span: 10 }}
                        layout="vertical"
                        onFinish={(values) => {
                            handleClick(values)
                        }}
                        onFinishFailed={(error) => {
                            console.log({ error })
                        }}
                    >
                        <Form.Item
                            name="title"
                            label="Title"
                            rules={[
                                {
                                    required: true,
                                    message: 'This field is required',
                                },
                            ]}
                            hasFeedback
                        >
                            <Input size="large" onChange={handleTitle} />
                        </Form.Item>

                        <Form.Item
                            name="description"
                            label="Description"
                            rules={[
                                {
                                    required: true,
                                    message: 'This field is required',
                                },
                            ]}
                            hasFeedback
                        >
                            <Input size="large" onChange={handleDescription} />
                        </Form.Item>
                        <Form.Item wrapperCol={{ span: 6 }}>
                            <Button
                                type="primary"
                                shape="round"
                                icon={<EditOutlined />}
                                htmlType="submit"
                            >
                                Update
                            </Button>
                        </Form.Item>
                    </Form>
                </SimpleCard>
            </Space>
        </Container>
    )
}

export default EditOrders
