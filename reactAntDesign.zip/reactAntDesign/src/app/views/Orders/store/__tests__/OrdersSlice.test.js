import store from 'app/redux/store'
import { OrdersAdded, OrdersDeleted, OrdersUpdated } from '../OrdersSlice'

describe('testing orders redux store reducers', () => {
    test('add orders to store test', () => {
        let state = store.getState().Orders
        expect(state.entities).toHaveLength(0)
        const initialInput = {
            id: 1,
            title: 'title',
            description: 'description',
        }
        store.dispatch(OrdersAdded(initialInput))
        state = store.getState().Orders
        expect(state.entities).toHaveLength(1)
    })

    test('update orders from store should change the length of the entities array in redux store', () => {
        const initialInput = {
            id: 2,
            title: 'title',
            description: 'description',
        }
        store.dispatch(OrdersAdded(initialInput))
        let state = store.getState().Orders
        expect(state.entities).toHaveLength(2)

        const updatedInput = {
            id: initialInput.id,
            title: 'title1',
            description: 'description1',
        }
        store.dispatch(OrdersUpdated(updatedInput))
        state = store.getState().Orders
        let changedOrders = state.entities.find((p) => p.id === 2)
        expect(changedOrders).toStrictEqual(updatedInput)
    })

    test('delete orders from store should reduce the length of the entities array in redux store', () => {
        const initialInput = {
            id: 3,
            title: 'title',
            description: 'description',
        }
        store.dispatch(OrdersAdded(initialInput))
        let state = store.getState().Orders
        expect(state.entities).toHaveLength(3)

        store.dispatch(
            OrdersDeleted({
                id: initialInput.id,
            })
        )
        state = store.getState().Orders
        expect(state.entities).toHaveLength(2)
    })
})
