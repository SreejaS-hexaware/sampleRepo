import axios from '../../../../../axios'
import MockAdapter from 'axios-mock-adapter'
import store from 'app/redux/store'
import {
    fetchOrders,
    addOrders,
    editOrders,
    deleteOrders,
} from '../Orders.action'

const getOrdersListResponse = [
    {
        id: 1,
        title: 'title',
        description: 'description',
    },
]

const addOrdersListResponse = (data) => {
    return { id: 2, ...data }
}
const editOrdersListResponse = (data) => {
    return data
}

describe('should test Orders redux tooklit asyncThunk api action and redux store updation', () => {
    const mock = new MockAdapter(axios)
    const endPoint = 'Orders'
    test('Should be able to fetch the orders list and update orders redux store', async () => {
        mock.onGet(`/${endPoint}`).reply(200, getOrdersListResponse)
        const result = await store.dispatch(fetchOrders())
        const ordersList = result.payload
        expect(result.type).toBe('Orders/fetchOrders/fulfilled')
        expect(ordersList).toEqual(getOrdersListResponse)

        const state = store.getState().Orders
        expect(state.entities).toEqual(ordersList)
    })

    test('Should be able to add new orders to list and make post api and update orders redux store', async () => {
        const body = {
            title: 'title',
            description: 'description',
        }
        mock.onPost(`/${endPoint}`, body).reply(
            201,
            addOrdersListResponse(body)
        )
        const result = await store.dispatch(addOrders(body))
        const ordersItem = result.payload
        expect(result.type).toBe('Orders/addOrders/fulfilled')
        expect(ordersItem).toEqual(addOrdersListResponse(body))

        const state = store.getState().Orders
        expect(state.entities).toContainEqual(addOrdersListResponse(body))
    })

    test('Should be able to edit orders in list and make put api call and update orders redux store', async () => {
        const body = {
            id: 1,
            title: 'title',
            description: 'description',
        }
        mock.onPut(`/${endPoint}/${body.id}`, body).reply(
            201,
            editOrdersListResponse(body)
        )
        const result = await store.dispatch(editOrders(body))
        const ordersItem = result.payload
        expect(result.type).toBe('Orders/editOrders/fulfilled')
        expect(ordersItem).toEqual(editOrdersListResponse(body))

        const state = store.getState().Orders
        let changedOrders = state.entities.find((p) => p.id === body.id)
        expect(changedOrders.name).toEqual(body.name)
    })

    test('Should be able to delete orders in list and update orders redux store', async () => {
        const input = {
            id: 2,
        }
        mock.onDelete(`/${endPoint}/${input.id}`, input).reply(200)
        let state = store.getState().Orders
        const initialLength = state.entities.length
        const result = await store.dispatch(deleteOrders(input))
        const deletId = result.payload
        expect(result.type).toBe('Orders/deleteOrders/fulfilled')
        expect(deletId).toEqual(input.id)

        state = store.getState().Orders
        const updateLength = initialLength - 1
        expect(state.entities.length).toEqual(updateLength)
    })
})
