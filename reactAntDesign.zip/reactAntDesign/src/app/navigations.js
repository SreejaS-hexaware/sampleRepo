export const navigations = [
    {
        name: 'Entities',
        path: '/',
        icon: 'dashboard',
        children: [
            {
                name: 'Orders',
                path: '/Orders',
                iconText: 'A',
            },
        ],
    },
]
