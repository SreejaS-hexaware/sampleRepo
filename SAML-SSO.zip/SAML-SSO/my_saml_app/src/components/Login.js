import './Login.css';
import profile from "./../image/a.png";
import email from "./../image/email.jpg";
import { useNavigate } from 'react-router-dom';



function Login() {

  const navigate = useNavigate();

  const handleSubmit = ()=>{
    console.log("You are now logged in successfully!!!")
    navigate("/home")
}

  return (
    <div className="main">
     <div className="sub-main">
       <div>
         <div className="imgs">
           <div className="container-image">
             <img src={profile} alt="profile" className="profile"/>

           </div>


         </div>
         <div>
           <h1>Login Page</h1>
           <div>
             <img src={email} alt="email" className="email"/>
             <input type="text" placeholder="Email ID" className="name"/>
           </div>
          <div className="login-button">
          <button onClick={handleSubmit}>Login</button>
          </div>
           
            <p className="link">
              <a href="#">Forgot password ?</a> Or<a href="#">Sign Up</a>
            </p>
           
 
         </div>
       </div>
       

     </div>
    </div>
  );
}

export default Login;