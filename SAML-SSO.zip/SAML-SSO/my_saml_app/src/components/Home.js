function Home() {
    return (
        <div>
            <h4>You are now logged in successfully!!!</h4>
        </div>
    )
}
export default Home;