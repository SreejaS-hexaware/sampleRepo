import { BrowserRouter as Router, useRoutes} from 'react-router-dom';
import './App.css';
import { AllPages } from './routes/routes'

function App() {
  const all_pages = useRoutes(AllPages())
  return (
    
    <div className="App">
      {all_pages}
    </div>
    
  );
}

export default App;
