import Home from "../components/Home"
import Login from "../components/Login"

export const AllPages = () => {
    const all_routes = [
        {
            path: '/home',
            element: <Home/>,
        },
        {
            path: '/',
            element: <Login/>,
        },
        
    ]
    return all_routes
}
