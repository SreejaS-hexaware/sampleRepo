const config = {
    // saml: {
    //     cert: './source/config/saml.pem',
    //     entryPoint: 'https://login.microsoftonline.com/506ff294-27be-4deb-a21e-dd8d6029576c/saml2',
    //     issuer: 'http://localhost:1337',
    //     options: {
    //         failureRedirect: '/login',
    //         failureFlash: true
    //     }
    // },
    server: {
        port: 1337
    },
    session: {
        resave: false,
        secret: 'supersecretamazingpassword',
        saveUninitialized: true
    }
};

export default config;
