import axios from 'axios';
import './App.css';
import React, { useEffect, useState } from 'react';

function App() {
  const [loading, setLoading] = useState(true);
    const [email, setEmail] = useState('');

    useEffect(() => {
        // logging.info('Initiating SAML check.', 'SAML');
        console.log("Initiating SAML Check...")

        axios({
            method: 'GET',
            url: 'http://localhost:1337/whoami',
            withCredentials: true
        })
        .then(response => {
            // logging.info(response.data.user, 'SAML');
            console.log(response.data.user)

            if (response.data.user.nameID)
            {
                setEmail(response.data.user.nameID);
                setLoading(false);
            }
            else
            {
                RedirectToLogin();    
            }
        })
        .catch(error => {
            // logging.error(error, 'SAML');
            console.log(error)
            RedirectToLogin();
        })
    }, []);

    const RedirectToLogin = () => {
        window.location.replace('http://localhost:1337/login');
    }

    if (loading)
        return <p>loading ...</p>

    return (
        <p>Hello {email}!</p>
    );
}

export default App;
