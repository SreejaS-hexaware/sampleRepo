import React, { useReducer } from 'react';
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css"
import "./App.css"
import { configurationIdentityServer } from './Configurations';
import { MultiAuthContainer } from './MultiAuth';
import { OidcProvider, withOidcSecure } from '@axa-fr/react-oidc';
import { SecureProfile } from './SecureProfile';

// const OidcSecureHoc = withOidcSecure(Profile);

const getRandomInt = (max) => {
  return Math.floor(Math.random() * max);
};


function App() {
  // eslint-disable-next-line @typescript-eslint/naming-convention
  
  return (<>

    <OidcProvider configuration={configurationIdentityServer} >
      <BrowserRouter>
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
          <a className="navbar-brand" href="/multi-auth">OIDC Authentication</a>
        </nav>

        <div>
          <Routes>
            <Route path="/profile" element={<SecureProfile></SecureProfile>} />
            <Route path="/multi-auth/*" element={<MultiAuthContainer></MultiAuthContainer>} />
          </Routes>
        </div>

      </BrowserRouter>
    </OidcProvider>
      </>
  );
}

export default App;
