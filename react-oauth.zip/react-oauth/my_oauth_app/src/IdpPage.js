import React, { useState } from 'react'

export const IdpPage = () => {

    const[loading, setLoading] = useState(false)
    const [users, setUsers] = useState(null)
    const [config, setConfig] = useState("")
    const [domain, setDomain] = useState("")

    const getFetchUsers = () => {
        setLoading(true);
        
        if(users != null){
            setLoading(false)
        console.log(users.issuer);            
        console.log(users.token_endpoint);
        console.log(users.authorization_endpoint);
        console.log(users.end_session_endpoint);
        }
        else{
            fetch(config).then(res => res.json()).then(result => {
                // setLoading(false)
                setUsers(result)
            }).catch(console.log);
        }
                
            
        
        
    }
    // const handleClick = () =>{
    //     getFetchUsers()
        
    // }
  return (
    <>
    <div className="Auth-form-container">
      <form className="Auth-form" action='' onSubmit={getFetchUsers}>
        <div className="Auth-form-content">
          <h3 className="Auth-form-title">Add IDP</h3>
          <div className="form-group mt-3">
            <label>Domain</label>
            <input
              type="text"
              className="form-control mt-1"
              placeholder="Enter your domain"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
            />
          </div>
          <div className="form-group mt-3">
            <label>Well Known Endpoint</label>
            <input
              type="text"
              className="form-control mt-1"
              placeholder="Enter your endpoint"
              value={config}
              onChange={(e)=> setConfig(e.target.value)}
            />
          </div>
          <div className="d-grid gap-2 mt-3">
            <button type='submit'  className="btn btn-primary">
              Proceed
            </button>
          </div>
        </div>
      </form>
    </div>
    </>
    
    
  )
}
