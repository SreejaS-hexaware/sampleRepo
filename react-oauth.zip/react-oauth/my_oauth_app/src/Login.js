import React, { useState } from 'react'
import {useOidc, OidcSecure, OidcProvider} from "@axa-fr/react-oidc";
import {c, configurationAzure, configurationOkta} from './App';
import AuthenticatingError from "./override/AuthenticateError"
import Authenticating from "./override/Authenticating"
import Loading from "./override/Loading"
import {CallBackSuccess} from "./override/Callback"
import SessionLost from "./override/SessionLost"
import ServiceWorkerNotSupported from "./override/ServiceWorkerNotSupported"


export const Login = ({handleConfig}) => {
    const {configName, setConfigName} = useState("config_okta")
    const [isSessionLost, setIsSessionLost] = useState(false)
    const [email, setEmail] = useState("")
    const [data, setData] = useState("")
    const { login, logout, renewTokens, isAuthenticated} = useOidc();

    const handleChange = (e) =>{
      setEmail(e.target.value)
      const arr = email.split('@');
        const domain = arr[1]
        return fetch(`http://localhost:4000/users/@${domain}/`)
        .then((result)=>{
          result.json().then((resp)=>{
            console.log(resp);
            handleConfig(resp.config);
            // if(resp.config != null){
            //   // if(c === configurationAzure)
            //   login('/profile')
            // }
          })
        })
    }
    const handleFetch = () =>{
      const arr = email.split('@');
        const domain = arr[1]
        return fetch(`http://localhost:4000/users/@${domain}/`)
        .then((result)=>{
          result.json().then((resp)=>{
            console.log(resp);
            handleConfig(resp.config);
            if(resp.config != null){
              // if(c === configurationAzure)
              login('/profile')
            }
          })
        })
        
        
    };
    // const handleClick = () =>{
    //   handleFetch();
    //   console.log(data)
    //   if(data!="")
    //   login('/profile');
    // }
    // const handleEvent = () =>{
    //   handleClick().then(() => {console.log(data)});
    // };

    const onSessionLost = ()=>{
      setIsSessionLost(true);
  }
    
  return (
    <>
        
    <div className="Auth-form-container">
      <form className="Auth-form" >
        <div className="Auth-form-content">
          <h3 className="Auth-form-title">Sign In</h3>
          <div className="form-group mt-3">
            <label>Email address</label>
            <input
              type="email"
              className="form-control mt-1"
              placeholder="Enter email"
              value={email}
              onChange={handleChange}
            />
          </div>
          <div className="d-grid gap-2 mt-3">
          {!isAuthenticated && <p><button type="button" className="btn btn-primary" onClick={() => {
            login('/profile')
            
            }}
            >proceed</button></p>}
          {isAuthenticated && <p><button type="button" className="btn btn-primary" onClick={() => logout()}>logout</button></p>}
          </div>
          <p>{data}</p>
          <p className="forgot-password text-right mt-2">
            Forgot <a href="#">password?</a>
          </p>
        </div>
      </form>
    </div>
    
    </>
    
    
  )
}
