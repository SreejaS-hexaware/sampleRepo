/* eslint-disable */
import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import { configurationAuth0, configurationAzure, configurationGoogle, configurationIdentityServer, configurationOkta } from './Configurations.js';
import { OidcProvider, useOidc, useOidcAccessToken, useOidcIdToken } from '@axa-fr/react-oidc';
import AuthenticatingError from './override/AuthenticateError';
import Authenticating from './override/Authenticating';
import { CallBackSuccess } from './override/Callback';
import Loading from './override/Loading';
import ServiceWorkerNotSupported from './override/ServiceWorkerNotSupported';
import SessionLost from './override/SessionLost';
import { SecureProfile } from './SecureProfile.js';

const MultiAuth = ({ configurationName, handleConfigurationChange, fname, domain }) => {
    const { login, logout, isAuthenticated } = useOidc(configurationName);
    
    return (
        <>
        
        {!isAuthenticated && 
            <div className="Auth-form-container">
      <form className="Auth-form" >
        <div className="Auth-form-content">
          <h3 className="Auth-form-title">Sign In</h3>
          <div className="form-group mt-3">
            <label>Email address</label>
            <input type="email"
              className="form-control mt-1"
              placeholder="Enter email"
              value={fname} 
              onChange={handleConfigurationChange} />
          </div>
          <div className="d-grid gap-2 mt-3">
          <p><button type="button" className="btn btn-primary" onClick={()=>{if(fname!=='' && (fname.split('@')[1]==='hexaware.com' || fname.split('@')[1] === 'citibank.com' || fname.split('@')[1] === 'gmail.com')) {login()}}}>Login</button></p>
          </div>
          <p className="forgot-password text-right mt-2">
            Forgot <a href="#">password?</a>
          </p>
          </div>
      </form>
      </div>}
          
          {isAuthenticated && <>
            <div className="Auth-logout-container">
          <div><SecureProfile></SecureProfile></div>
          <div><p><button type="button" className="btn btn-primary" onClick={()=>logout()}>Logout</button></p></div>
          </div>
          </>
          }
          
         </> 
    );
};

if (!sessionStorage.configurationName) {
    sessionStorage.configurationName = 'config_classic';
}

export const MultiAuthContainer = () => {
    const [isSessionLost, setIsSessionLost] = useState(false);
    const [fname, setFname] = useState('');
    const [domain, setDomain] = useState('');
    const [configurationName, setConfigurationName] = useState(sessionStorage.configurationName);
    const callBack = window.location.origin + '/multi-auth/authentification/callback2';
    const silent_redirect_uri = window.location.origin + '/multi-auth/authentification/silent-callback2';
    const configurations = {
        config_classic: {
            ...configurationIdentityServer,
            redirect_uri: callBack,
            silent_redirect_uri,
            scope: 'openid profile email api offline_access',
        },
        config_google: { ...configurationGoogle },
        config_auth0: { ...configurationAuth0 },
        config_okta: { ...configurationOkta },
        config_azure: { ...configurationAzure },
    };

    useEffect(() => {
        console.log(fname)
        if(fname.split('@')[1] === 'hexaware.com' || fname.split('@')[1] === 'citibank.com' || fname.split('@')[1] === 'gmail.com'){
            // const c = fname.split('@')[1]
            fetch(`http://localhost:4000/users/@${fname.split('@')[1]}/`)
        .then((result) => {
          result.json().then((resp) => {
            console.log(resp);
            if (resp.config === 'configurationAuth0') {
                const configurationName = 'config_auth0';
                sessionStorage.configurationName = configurationName;
                setConfigurationName(configurationName);
            } else if (resp.config === 'configurationAzure') {
                const configurationName = 'config_azure';
                sessionStorage.configurationName = configurationName;
                /* eslint-disable */
                setConfigurationName(configurationName); 
            } else if (resp.config === 'configurationOkta') {
                const configurationName = 'config_okta';
                sessionStorage.configurationName = configurationName;
                setConfigurationName(configurationName);
            }
          });
    });
        }
      }, [fname]);


    const handleConfigurationChange = (e)=> {
        setFname(e.target.value);}
        // setDomain(fname.split('@')[1]);}

    const onSessionLost = () => {
        setIsSessionLost(true);
    };

    return (
        <>
        <OidcProvider configuration={configurations[configurationName]}
                      configurationName={configurationName}
                      loadingComponent={Loading}
                      authenticatingErrorComponent={AuthenticatingError}
                      authenticatingComponent={Authenticating}
                      serviceWorkerNotSupportedComponent={ServiceWorkerNotSupported}
                      callbackSuccessComponent={CallBackSuccess}
                      onSessionLost={onSessionLost}
        >
            { isSessionLost && <SessionLost configurationName={configurationName}/>}
            <MultiAuth configurationName={configurationName} handleConfigurationChange={handleConfigurationChange} fname={fname} domain={domain} />
            {/* <DisplayAccessToken configurationName={configurationName} /> */}
        </OidcProvider>
    </>
    );
};
