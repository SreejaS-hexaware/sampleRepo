import React from 'react'
import { OidcSecure} from "@axa-fr/react-oidc";

const Profile = () => {
  return (
    // <OidcSecure>
    <div>Hii...You have successfully logged in!!!</div>
    // </OidcSecure>
  )
}

export const SecureProfile = () => <Profile />;