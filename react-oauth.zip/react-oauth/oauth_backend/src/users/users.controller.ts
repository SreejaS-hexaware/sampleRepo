import {
    Controller,
    Post,
    Body,
    Get,
    Param,
    Patch,
    Delete,
  } from '@nestjs/common';
// import { Configurations } from './users.model';
  
  import { UsersService } from './users.service';
  
  @Controller('users')
  export class UsersController {
    constructor(private readonly usersService: UsersService) {}
  
    @Post()
    async addDomain(
      @Body('domain') userDomain: string,
      @Body('config') userConfig: string
    ) {
      const generatedId = await this.usersService.insertDomain(
        userDomain,
        userConfig
      );
      return { id: generatedId };
    }
  
    // @Get()
    // async getAllProducts() {
    //   const products = await this.productsService.getProducts();
    //   return products;
    // }
  
    @Get(':domain')
    getProduct(@Param('domain') domain: string) {
      return this.usersService.getConfigByDomain(domain);
    }
  
    
  }