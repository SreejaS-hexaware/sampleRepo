import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

import { UsersDomain } from './users.model';

@Injectable()
export class UsersService {
  constructor(
    @InjectModel('UsersDomain') private readonly usersDomainModel: Model<UsersDomain>,
  ) {}

  async insertDomain(domain: string, config: string) {
    const newDomain = new this.usersDomainModel({
      domain,
      config
    });
    const result = await newDomain.save();
    return result.id as string;
  }


  async getConfigByDomain(domain: string) {
    const userConfig = await this.findConfig(domain);
    return {
      config: userConfig.config
        // clientId: userConfig.config.clientId,
        // redirectUri: userConfig.config.redirectUri,
        // scope: userConfig.config.scope,
        // authority: userConfig.config.authority,
        // issuer: userConfig.config.authority_configuration.issuer,
        // authorization_endpoint: userConfig.config.authority_configuration.authorization_endpoint,
        // token_endpoint: userConfig.config.authority_configuration.token_endpoint,
        // end_session_endpoint: userConfig.config.authority_configuration.end_session_endpoint
    };
  }

  private async findConfig(domain: string): Promise<UsersDomain> {
    let userConfig;
    try {
      userConfig = await this.usersDomainModel.findOne({ domain: domain }).exec();
    } catch (error) {
      throw new NotFoundException('Could not find domain.');
    }
    if (!userConfig) {
      throw new NotFoundException('Could not find domain.');
    }
    return userConfig;
  }
}