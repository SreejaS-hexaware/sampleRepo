import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as mongoose from 'mongoose';

export type UsersDomainDocument = UsersDomain & Document;

// @Schema()
// export class AuthorityConfig {
//     issuer?: string;
//     authorization_endpoint?: string;
//     token_endpoint?: string;
//     end_session_endpoint?: string;
// }

// @Schema()
// export class Configurations {
//   clientId?: string;
//   redirectUri?: string;
//   scope?: string;
//   authority?: string;
//   authority_configuration: AuthorityConfig;
// }
@Schema()
export class UsersDomain {
    @Prop({ required: true })
    domain: string;
    @Prop({ required: true})
    config: string;
    
}
export const UserSchema = SchemaFactory.createForClass(UsersDomain);